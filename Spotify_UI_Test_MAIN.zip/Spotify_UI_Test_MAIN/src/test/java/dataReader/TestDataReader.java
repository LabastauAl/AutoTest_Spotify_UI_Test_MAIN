package dataReader;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class TestDataReader {
    private static Properties properties;
    private static FileInputStream fileInputStream;

    public static String getProperties(String key) throws IOException {
        String dataValue;
        properties = new Properties();
        fileInputStream = new FileInputStream("src/test/java/resources/testData.properties");
        properties.load(fileInputStream);
        dataValue = properties.getProperty(key);
        fileInputStream.close();
        return dataValue;
    }
}
