package tests.negativeScenarios;

import org.testng.Assert;
import org.testng.annotations.*;
import pageObjects.accountPages.LoginPage;
import pageObjects.spotify_Pages.SpotifyStartPage;
import utils.WebDriverSingleton;

public class LoginTestCase {

    protected static SpotifyStartPage spotifyStartPage = new SpotifyStartPage();
    protected static LoginPage loginPage = new LoginPage();

    @BeforeClass(enabled = false)
    public static void openSpotify() throws InterruptedException {
        WebDriverSingleton.getWebDriver().get("https://open.spotify.com/");
        Thread.sleep(1000);
        spotifyStartPage.closeCookies();
    }

    @Test(description = "Checking enter the account with wrong credential values", dataProvider = "wrong credentials")
    public static void enterToAccount(String login, String password) throws InterruptedException {
        spotifyStartPage.loginPageEnter();
        loginPage.setLogin(login);
        loginPage.setPassword(password);
        loginPage.checkBoxControl();
        loginPage.loginEnter();
        Thread.sleep(1000);
        Boolean warningBanner = loginPage.getWarningBanner().isDisplayed();
        Assert.assertTrue(warningBanner, "The web element is not presented on the web page");

        loginPage.refreshPage();
    }

    @DataProvider(name = "wrong credentials")
    public Object[][] setWrongCredentials() {
        return new Object[][]{
                {"wrong@login", "wrongPassword"},
                {"wrong@login", ""},
                {"", "wrongPassword"}
        };
    }

    @AfterClass
    public static void returnToStartPage() throws InterruptedException {
        WebDriverSingleton.getWebDriver().get("https://open.spotify.com/");
        Thread.sleep(1000);
    }

    @AfterTest(enabled = false)
    public static void quitDriver() {
        WebDriverSingleton.quitDriver();
    }

}
