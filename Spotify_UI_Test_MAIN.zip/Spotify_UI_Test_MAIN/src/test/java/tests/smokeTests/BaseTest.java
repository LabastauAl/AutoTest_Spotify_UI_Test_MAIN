package tests.smokeTests;

import dataReader.TestDataReader;
import org.testng.Assert;
import org.testng.annotations.*;
import pageObjects.PageObjectBasics;
import pageObjects.accountPages.ProfilePage;
import pageObjects.leftMenuAndPlayer.AccountLeftMenuPanel;
import pageObjects.spotify_Pages.PlaylistEditor;
import pageObjects.leftMenuAndPlayer.StartingLeftMenuPanel;
import pageObjects.leftMenuAndPlayer.PlayerPanel;
import pageObjects.accountPages.LoginPage;
import pageObjects.spotify_Pages.PlayListPage;
import pageObjects.spotify_Pages.SpotifyStartPage;
import utils.WebDriverSingleton;

import java.io.IOException;

public class BaseTest {
    protected static SpotifyStartPage spotifyStartPage = new SpotifyStartPage();
    protected static StartingLeftMenuPanel startingLeftMenuPanel = new StartingLeftMenuPanel();
    protected static AccountLeftMenuPanel accountLeftMenuPanel = new AccountLeftMenuPanel();
    protected static PlaylistEditor playlistEditor = new PlaylistEditor();
    protected static PlayListPage playListPage = new PlayListPage();
    protected static PlayerPanel playerPanel = new PlayerPanel();
    protected static LoginPage loginPage = new LoginPage();
    protected static ProfilePage profilePage = new ProfilePage();


    @BeforeSuite
    public static void startActions() throws InterruptedException {
        WebDriverSingleton.getWebDriver().get("https://open.spotify.com");
        Thread.sleep(1000);
        spotifyStartPage.closeCookies();
    }

    @Test(description = "Validate start page title", priority = 1)
    public static void pageTitle() {
        String pageTitle = WebDriverSingleton.getWebDriver().getTitle();
        System.out.println(pageTitle);
        Assert.assertEquals(pageTitle, "Spotify - Web Player: Music for everyone");
    }

    @Test(description = "Checking left menu panel fields without entering the account", priority = 2)
    public static void checkingLeftMenu() throws InterruptedException {
        startingLeftMenuPanel.clickOnYouLibraryButton();
        Thread.sleep(1000);
        startingLeftMenuPanel.clickOnSearchPageLink();
        System.out.println(WebDriverSingleton.getWebDriver().getCurrentUrl());
        Assert.assertEquals(WebDriverSingleton.getWebDriver().getCurrentUrl(), "https://open.spotify.com/search");
        Thread.sleep(1000);
        startingLeftMenuPanel.clickOnCreatePlaylistButton();
        startingLeftMenuPanel.clickOnStartPageLink();
        Thread.sleep(1000);
        Assert.assertEquals(WebDriverSingleton.getWebDriver().getCurrentUrl(), "https://open.spotify.com/");
        startingLeftMenuPanel.clickOnLikedSongsButton();

    }

    @Test(description = "Enter the account through the music styles cards links", priority = 3)
    public static void enterTheAccount() throws InterruptedException, IOException {
        spotifyStartPage.cardClick();
        Thread.sleep(2000);
        System.out.println(WebDriverSingleton.getWebDriver().getTitle());
        spotifyStartPage.getListOfSongs();
        spotifyStartPage.randomSong();

        loginPage.setLogin(TestDataReader.getProperties("account_email"));
        Thread.sleep(1000);
        loginPage.setPassword(TestDataReader.getProperties("account_password"));
        Thread.sleep(1000);
        loginPage.checkBoxControl();
        Thread.sleep(1000);
        Assert.assertEquals(WebDriverSingleton.getWebDriver().getTitle(), "Войти - Spotify");
        loginPage.loginEnter();
    }

    @Test(description = "Create new playlist and add some searched songs", priority = 4)
    public static void createPlaylist() throws InterruptedException, IOException {
        accountLeftMenuPanel.createNewPlaylist();
        playlistEditor.setPlayList(TestDataReader.getProperties("playlist_title"));
        playListPage.searchBand(TestDataReader.getProperties("music_search_value"));
        playListPage.chooseFromSearchResultList(TestDataReader.getProperties("music_search_value"));
        playListPage.addSongsToPlayList();
        playListPage.getSongsAmount();
        playListPage.playSongFromCurrentPlayList();
        playListPage.getCurrentSong_title();

        Thread.sleep(5000);
        playerPanel.pauseCurrentSong();
        playListPage.compareSongName(playListPage.getCurrentSong_title(), playerPanel.getCurrentSongPlayer());
        Assert.assertEquals(playListPage.getCurrentSong_title(), playerPanel.getCurrentSongPlayer());
    }


    @Test(description = "Validate and change User Name", priority = 5)
    public static void validateUserName() throws InterruptedException {
        profilePage.enterToProfilePage();
        Thread.sleep(1000);
        Assert.assertEquals(profilePage.getUserNameFromWidget(), profilePage.getUserNameFromProfilePage());
        profilePage.changeUserName();
        Thread.sleep(1000);
        Assert.assertEquals(profilePage.getUserNameFromWidget(), profilePage.getUserNameFromProfilePage());
        Thread.sleep(1000);
    }

    @AfterClass(enabled = true)
    public static void exitAccount() throws InterruptedException {
        profilePage.exitAccount();
        Thread.sleep(1000);
    }

    @AfterSuite
    public static void endOfSession() {
        PageObjectBasics.endOfSession();
    }

}
