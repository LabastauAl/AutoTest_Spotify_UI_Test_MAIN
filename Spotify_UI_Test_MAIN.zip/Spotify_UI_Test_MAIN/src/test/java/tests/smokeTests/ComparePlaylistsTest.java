package tests.smokeTests;

import dataReader.TestDataReader;
import org.testng.Assert;
import org.testng.annotations.*;
import pageObjects.accountPages.LoginPage;
import pageObjects.accountPages.ProfilePage;
import pageObjects.leftMenuAndPlayer.AccountLeftMenuPanel;
import pageObjects.leftMenuAndPlayer.StartingLeftMenuPanel;
import pageObjects.spotify_Pages.CollectionPlaylists;
import pageObjects.spotify_Pages.SpotifyStartPage;
import utils.WebDriverSingleton;

import java.io.IOException;

public class ComparePlaylistsTest {
    protected static SpotifyStartPage spotifyStartPage = new SpotifyStartPage();
    protected static StartingLeftMenuPanel startingLeftMenuPanel = new StartingLeftMenuPanel();
    protected static LoginPage loginPage = new LoginPage();
    protected static CollectionPlaylists collectionPlaylists = new CollectionPlaylists();
    protected static AccountLeftMenuPanel accountLeftMenuPanel = new AccountLeftMenuPanel();
    protected static ProfilePage profilePage = new ProfilePage();

    @BeforeClass(enabled = false)
    public static void openSpotify() throws InterruptedException {
        WebDriverSingleton.getWebDriver().get("https://open.spotify.com/");
        Thread.sleep(1000);
        spotifyStartPage.closeCookies();
    }

    @Test(description = "Enter the account", priority = 1)
    public static void enterTheAccount() throws InterruptedException, IOException {
        startingLeftMenuPanel.goToYourLibraryPage();
        Thread.sleep(1000);
        Assert.assertEquals(WebDriverSingleton.getWebDriver().getTitle(), "Войти - Spotify");
        loginPage.setLogin(TestDataReader.getProperties("account_email"));
        loginPage.setPassword(TestDataReader.getProperties("account_password"));
        loginPage.checkBoxControl();

        loginPage.loginEnter();
    }

    @Test(description = "Compare amount of available playlists from Playlists page and left menu", priority = 2)
    public static void comparePlaylists() throws InterruptedException {
        Thread.sleep(3000);
        Assert.assertEquals(WebDriverSingleton.getWebDriver().getCurrentUrl(), "https://open.spotify.com/collection/playlists");
        Assert.assertEquals(accountLeftMenuPanel.getAmountOfLeftMenuPlaylists(), collectionPlaylists.getAmountOfPlaylistsCards());
        collectionPlaylists.countPlayLists();
    }

    @Test(description = "Validate and change User Name", priority = 3)
    public static void validateUserName() throws InterruptedException {
        profilePage.enterToProfilePage();
        Thread.sleep(1000);
        Assert.assertEquals(profilePage.getUserNameFromWidget(), profilePage.getUserNameFromProfilePage());
        profilePage.changeUserName();
        Thread.sleep(1000);
        Assert.assertEquals(profilePage.getUserNameFromWidget(), profilePage.getUserNameFromProfilePage());
        Thread.sleep(1000);
    }

    @AfterClass(enabled = true)
    public static void exitAccount() throws InterruptedException {
        profilePage.exitAccount();
        Thread.sleep(1000);
    }

    @AfterTest(enabled = false)
    public static void quitDriver() {
        WebDriverSingleton.quitDriver();
    }

}