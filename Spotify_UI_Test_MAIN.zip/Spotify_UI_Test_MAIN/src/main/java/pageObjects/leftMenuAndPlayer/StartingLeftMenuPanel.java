package pageObjects.leftMenuAndPlayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;

import java.util.List;

public class StartingLeftMenuPanel extends PageObjectBasics {

    public StartingLeftMenuPanel() {
    }

    @FindBy(xpath = "//ul[@class='RSg3qFREWrqWCuUvDpJR']/li[1]")
    private WebElement leftMenu_StartPageLink;

    @FindBy(xpath = "//ul[@class='RSg3qFREWrqWCuUvDpJR']/li[2]")
    private WebElement leftMenu_SearchPageLink;

    @FindBy(xpath = "//ul[@class='RSg3qFREWrqWCuUvDpJR']/li[3]")
    private WebElement leftMenu_YourLibraryButton;

    @FindBy(xpath = "//button[@data-testid='create-playlist-button']")
    private WebElement leftMenu_CreatePlaylistButton;

    @FindBy(xpath = "//a[@href='/collection/tracks']")
    private WebElement leftMenu_LikedSongsButton;

    @FindBy(xpath = "//div[contains(@data-testid, 'hook')]//button[@data-encore-id='buttonTertiary']")
    private WebElement leftMenu_Submenu_NotNowButton;

    @FindBy(xpath = "//div[contains(@data-testid, 'hook')]//button[@data-encore-id='buttonPrimary']")
    private WebElement leftMenu_Submenu_EnterButton;



    public void clickOnYouLibraryButton() throws InterruptedException {
        leftMenu_YourLibraryButton.click();
        Thread.sleep(1000);
        leftMenu_Submenu_NotNowButton.click();
    }

    public void clickOnCreatePlaylistButton() throws InterruptedException {
        leftMenu_CreatePlaylistButton.click();
        Thread.sleep(1000);
        leftMenu_Submenu_NotNowButton.click();
    }

    public void clickOnLikedSongsButton() throws InterruptedException {
        leftMenu_LikedSongsButton.click();
        Thread.sleep(1000);
        leftMenu_Submenu_NotNowButton.click();
    }

    public void clickOnStartPageLink() {
        leftMenu_StartPageLink.click();
    }

    public void clickOnSearchPageLink() {
        leftMenu_SearchPageLink.click();
    }

    public void goToYourLibraryPage() throws InterruptedException {
        leftMenu_YourLibraryButton.click();
        Thread.sleep(1000);
        leftMenu_Submenu_EnterButton.click();
    }



}
