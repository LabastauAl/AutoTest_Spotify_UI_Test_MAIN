package pageObjects.leftMenuAndPlayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;

public class PlayerPanel extends PageObjectBasics {

    public PlayerPanel() {
    }

    @FindBy(xpath = "//button[@data-testid='control-button-playpause']")
    private WebElement playerPlayPauseButton;

    @FindBy(xpath = "//a[@data-testid='context-item-link']")
    private WebElement currentSong;

    public void pauseCurrentSong() {
        playerPlayPauseButton.click();
    }

    public String getCurrentSongPlayer() {
        String curSongPlayer = currentSong.getText();
        return curSongPlayer;
    }
}
