package pageObjects.leftMenuAndPlayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;

import java.util.List;

public class AccountLeftMenuPanel extends PageObjectBasics {

    public AccountLeftMenuPanel(){
    }

    @FindBy(xpath = "//button[@data-encore-id='buttonTertiary'][2]/preceding-sibling::button/span")
    private WebElement myCollection_plusIcon;
    @FindBy (xpath = "//div[@id='context-menu']//li[1]")     //*** old xpath ---> //button[@data-testid='create-playlist-button']
    private WebElement createPlayListButton;
    @FindBy(xpath = "//div[contains(@aria-labelledby,'listrow-title-spotify') and @data-encore-id='listRow']/div[4]/div/p")
    private static List<WebElement> existingPlayLists;

    public void createNewPlaylist(){
        myCollection_plusIcon.click();
        waitForVisibility(createPlayListButton).click();
    }
    public static List<WebElement> showPlaylistsFromLeftPanel() {
        return existingPlayLists;
    }
    public static int getAmountOfLeftMenuPlaylists(){
        return existingPlayLists.size();
    }
}
