package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.WebDriverSingleton;

import java.time.Duration;
import java.util.List;

public class PageObjectBasics {
    protected static WebDriver driver;

    public PageObjectBasics() {
        driver = WebDriverSingleton.getWebDriver();
        PageFactory.initElements(driver, this);
    }

    /*
    public PageObjectBasics(WebDriver driver){
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }
    */

    public void goToPage(String url) {
        driver.get(url);
    }

    public static void endOfSession() {
        WebDriverSingleton.quitDriver();
    }

    /*
    protected WebElement waitForPresence(By locator){
        WebDriverWait explicitWait = new WebDriverWait(driver, Duration.ofSeconds(20));
        return explicitWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }*/

    protected WebElement waitForVisibility(WebElement element) {
        new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.visibilityOf(element));
        return element;
    }

    protected List<WebElement> waitForVisibility(List<WebElement> listOfElements){
        new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.visibilityOfAllElements(listOfElements));
        return listOfElements;
    }

}