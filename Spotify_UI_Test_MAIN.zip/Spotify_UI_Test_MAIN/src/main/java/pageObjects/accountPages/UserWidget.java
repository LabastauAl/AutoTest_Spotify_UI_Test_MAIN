package pageObjects.accountPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;

public class UserWidget extends PageObjectBasics {
    public UserWidget(){
    }
    @FindBy(xpath = "//button[@data-testid='user-widget-link']")
    private WebElement accountOptionsTopButton;

    @FindBy(xpath = "//button[@data-testid='user-widget-dropdown-logout']")
    private  WebElement accountOptionsExit;

    public void exitAccount(){
        accountOptionsTopButton.click();
        waitForVisibility(accountOptionsExit).click();
    }
}
