package pageObjects.accountPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;

public class LoginPage extends PageObjectBasics {

    public LoginPage() {
    }

    //private By loginField = By.xpath("//input[@id='login-username']");
    //private By passwordField = By.xpath("//input[@id='login-password']");
    //private By loginButton = By.xpath("//button[@id='login-button']");
    //private By loginCheckbox = By.xpath("//label[@for='login-remember']/span");

    @FindBy(xpath = "//input[@id='login-username']")
    private WebElement loginField;
    @FindBy(xpath = "//input[@id='login-password']")
    private WebElement passwordField;
    @FindBy(xpath = "//button[@id='login-button']")
    private WebElement loginButton;
    @FindBy(xpath = "//input[@data-testid='login-remember']/following-sibling::span")     //*** old xpath ---> //label[@for='login-remember']/span
    private WebElement loginCheckbox;

    @FindBy(xpath = "//div[@data-encore-id='banner']")
    private WebElement warningBanner;

    //private String loginEmail = LOGIN_EMAIL;
    //private String loginPassword = LOGIN_PASSWORD;

    public LoginPage setLogin(String loginEmail) {
        //driver.findElement(loginField).click();
        //driver.findElement(loginField).clear();
        loginField.clear();
        loginField.sendKeys(loginEmail);
        return this;
    }

    public LoginPage setPassword(String loginPassword) {
        passwordField.clear();
        passwordField.sendKeys(loginPassword);
        //passwordField.sendKeys(Keys.TAB);
        return this;
    }

    public LoginPage checkBoxControl() {
        loginCheckbox.click();
        return this;
    }

    public LoginPage loginEnter() {
        loginButton.click();
        return this;
    }

    public WebElement getWarningBanner() {
        return warningBanner;
    }

    public void refreshPage(){
        driver.navigate().refresh();
    }
}
