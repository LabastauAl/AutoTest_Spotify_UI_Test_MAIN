package pageObjects.accountPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;

public class ProfilePage extends PageObjectBasics {
    public ProfilePage(){

    }

//    @FindBy(xpath = "//span[@data-testid='user-widget-name']")
//    private WebElement userWidget_ButtonUserName;

    @FindBy(xpath = "//button[@data-testid='user-widget-link']/figure")
    private WebElement userWidget_AccountOptionsTopButton;

    @FindBy(xpath = "//div[@data-testid='user-widget-menu']/ul/li[2]")
    private WebElement userWidget_ProfileButton;

    @FindBy(xpath = "//button[@data-testid='user-widget-dropdown-logout']")
    private  WebElement userWidget_ExitButton;

    @FindBy(xpath = "//span[@data-testid='entityTitle']")
    private WebElement profileName;

    @FindBy(xpath = "//input[@data-testid='user-edit-name-input']")
    private WebElement profileDetailsPopup_NameField;

    @FindBy(xpath = "//button[contains(@class,'Button-sc-qlcn5g-0') and @data-encore-id='buttonPrimary']/span[contains(@class,'ODKlM')]")     //*** old xpath ---> //button[@data-encore-id='buttonPrimary' and @class='Button-sc-qlcn5g-0 eeDakC']
    private WebElement profileDetailsPopup_SaveButton;


    public String getUserNameFromWidget(){
        return userWidget_AccountOptionsTopButton.getAttribute("title");
    }

    public String getUserNameFromProfilePage(){
        return profileName.getAttribute("textContent");
    }

    public void enterToProfilePage(){
        userWidget_AccountOptionsTopButton.click();
        waitForVisibility(userWidget_ProfileButton).click();
    }

    public void changeUserName(){
        profileName.click();
        profileDetailsPopup_NameField.clear();
        profileDetailsPopup_NameField.sendKeys("MetalHead_" +((int) (Math.random()*2023)));
        profileDetailsPopup_SaveButton.click();
    }


    public void exitAccount(){
        userWidget_AccountOptionsTopButton.click();
        waitForVisibility(userWidget_ExitButton).click();
    }
}
