package pageObjects.spotify_Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;

import java.util.List;
import java.util.Random;

public class PlayListPage extends PageObjectBasics {
    public PlayListPage(){
    }

    @FindBy(xpath = "//div[@class='contentSpacing']//input[@role='searchbox']")      //*** old xpath ---> //div[@role='search']/input
    private WebElement inputField_search;
    @FindBy(xpath = "//div[@data-testid='playlist-inline-curation-loaded-results']/div/div[2]/div")
    private List<WebElement> searchingResults;

    @FindBy(xpath = "//button[@data-testid='add-to-playlist-button']") // //div[@role='row' and @aria-rowindex and @aria-selected]/div[@data-testid]
    private List<WebElement> addSong_toPlayList;

    @FindBy(xpath = "//div[@data-testid='playlist-tracklist']//div[@data-testid='tracklist-row']/div[1]/div")
    private List<WebElement> songs_FromPlaylist;

    @FindBy(xpath = "//div[@data-testid='playlist-tracklist']//a[@data-testid='internal-track-link']")
    private List<WebElement> nameSong_FromPlayList;

    private int random_song;


    //Search Songs and add to Playlist methods

    public void searchBand(String key){
        inputField_search.click();
        inputField_search.clear();
        inputField_search.sendKeys(key);
    }

    public void chooseFromSearchResultList(String musicSearchString){
        String searchAttr;
        for(int i=0; i< searchingResults.size(); i++){
            searchAttr = searchingResults.get(i).getAttribute("textContent");
            if(searchAttr.contains(musicSearchString)&&searchAttr.contains("Исполнитель")
            || searchAttr.contains(musicSearchString)&&searchAttr.contains("Artist")) {       //The attribute content "Исполнитель" should been changed for another localisation
                searchingResults.get(i).click();
                break;
            }
        }
    }

    public void addSongsToPlayList(){
        Actions actions = new Actions(driver);
        for(int i=0; i< addSong_toPlayList.size(); i++){
            actions.moveToElement(addSong_toPlayList.get(i)).pause(500).perform();
            addSong_toPlayList.get(i).click();
        }
    }
    //Перетягивать элементы в плейлист не хочет
    /*
    public void dragSongToPlaylist(){
        Actions dragSong = new Actions(driver);
        dragSong.dragAndDrop(topBandSong, playList).build().perform();
        //dragSong.moveToElement(topBandSong).clickAndHold(topBandSong).moveToElement(playList).release().build().perform();
    } */

    // Play song and get info methods
    public void getSongsAmount() throws InterruptedException {
        Thread.sleep(2000);
        System.out.println("Amount of songs in the current playlist: " +songs_FromPlaylist.size());
    }
    public int playSongFromCurrentPlayList() {
        Random ran = new Random();
        int randomSong = ran.nextInt(songs_FromPlaylist.size());
        Actions actions = new Actions(driver);
        actions.moveToElement(songs_FromPlaylist.get(randomSong)).pause(2000).click().perform();
        System.out.println("The number of playing song from current Playlist is: " +(randomSong+1)+ "\n");
        return random_song = randomSong;
    }



    public String getCurrentSong_title(){
        String currentSong_PlayList = nameSong_FromPlayList.get(random_song).getText();
        return currentSong_PlayList;
    }


    public void compareSongName(String curPlayList, String curPlayer){
        boolean comp = false;

        if (curPlayList.equals(curPlayer))
            comp = true;
        System.out.println("Compare of titles - " + comp);
        System.out.println("The title of currently playing song by playlist is - " +curPlayList);
        System.out.println("The title of currently playing song by player panel is - " +curPlayer+ "\n");
    }
}
