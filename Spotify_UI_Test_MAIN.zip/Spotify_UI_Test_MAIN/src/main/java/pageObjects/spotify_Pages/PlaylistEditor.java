package pageObjects.spotify_Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;

public class PlaylistEditor extends PageObjectBasics {

    public PlaylistEditor(){
    }

    @FindBy(xpath = "//button[@data-testid='more-button']")     // //div[@data-testid='action-bar-row']/child::button
    private WebElement options_PlayListButton;

    @FindBy(xpath = "//li[@role='presentation'][3]/button")
    private WebElement options_ChangePlayListInfo;

    @FindBy(xpath = "//input[@data-testid='playlist-edit-details-name-input']")
    private WebElement playListInfo_InputfieldPlayListName;

    @FindBy(xpath = "//button[@data-testid='playlist-edit-details-save-button']")
    private WebElement playListInfo_SaveButton;


    public void setPlayList(String key) {

        waitForVisibility(options_PlayListButton).click();
        options_ChangePlayListInfo.click();
        playListInfo_InputfieldPlayListName.click();
        playListInfo_InputfieldPlayListName.clear();
        playListInfo_InputfieldPlayListName.sendKeys(key);
        playListInfo_SaveButton.click();
    }


}
