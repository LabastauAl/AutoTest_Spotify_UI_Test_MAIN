package pageObjects.spotify_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;

import java.util.List;

public class SpotifyStartPage extends PageObjectBasics {
    public SpotifyStartPage() {
    }

    @FindBy(xpath = "//div[@id='onetrust-close-btn-container']/button")
    private WebElement closeCookiesButton;
    @FindBy(xpath = "//button[@data-testid='login-button']")
    private WebElement loginButton;
    @FindBy(xpath = "//div/a[@title='Rock Classics']")
    private WebElement startPageCard;
    @FindBy(xpath = "//div[@data-testid='tracklist-row']/div/div/a")
    private List<WebElement> songsFromCard;
    @FindBy(xpath = "//div[@data-testid='tracklist-row']/div[1]")
    private List<WebElement> songsFromCard_playbutton;
    @FindBy(xpath = "//a[@href='#']")
    private WebElement popup_EnterButton;


    public void closeCookies() {
        if(closeCookiesButton.isDisplayed())
        closeCookiesButton.click();
    }

    public void loginPageEnter() {
        loginButton.click();
    }


    public void cardClick() {
        startPageCard.click();
    }

    public void getListOfSongs() {
        for (int i = 0; i < songsFromCard.size(); i++) {
            System.out.println(songsFromCard_playbutton.get(i).getAttribute("textContent") + "\t" +
                    songsFromCard.get(i).getAttribute("textContent"));
        }
        System.out.println("\nAmount of visible positions from start song list:\t" + songsFromCard.size());
        System.out.println("Amount of corresponding play buttons:\t" + songsFromCard_playbutton.size());
    }

    public void randomSong() {
        //Random ran = new Random();
        //int random_song = ran.nextInt(songFromCard.size());
        int random_song = (int) (Math.random() * songsFromCard.size());
        if (random_song == 0) random_song += 1;

        Actions actions = new Actions(driver);
        actions.moveToElement(songsFromCard.get(random_song)).pause(500).perform();

        System.out.println("The number of randomly chosen song:\t" + (random_song + 1));
        System.out.println("The title of this song:\t " + songsFromCard.get(random_song).getAttribute("textContent") + "\n");

        songsFromCard_playbutton.get(random_song).click();
        waitForVisibility(popup_EnterButton).click();
    }

}
