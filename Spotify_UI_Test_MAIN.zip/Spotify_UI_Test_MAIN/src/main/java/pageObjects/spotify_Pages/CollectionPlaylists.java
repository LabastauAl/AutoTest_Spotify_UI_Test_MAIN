package pageObjects.spotify_Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageObjects.PageObjectBasics;
import pageObjects.leftMenuAndPlayer.AccountLeftMenuPanel;


import java.util.List;

public class CollectionPlaylists extends PageObjectBasics {
    public CollectionPlaylists() {
    }


    @FindBy(xpath = "//div[@data-testid='card-click-handler']/../div/a")
    private List<WebElement> playListsCards;

    public void countPlayLists() {
        waitForVisibility(playListsCards);
        String title_playListCard;
        String title_playListLeftPanel;
        Boolean compare;

        for (int i = 0; i < playListsCards.size(); i++) {
            compare = false;
            title_playListCard = playListsCards.get(i).getAttribute("textContent");
            title_playListLeftPanel = AccountLeftMenuPanel.showPlaylistsFromLeftPanel().get(i).getAttribute("textContent");
            if (title_playListCard.equals(title_playListLeftPanel)) {
                compare = true;
                System.out.println("Title of playlist by the card:\t" + title_playListCard + "\nTitle of playlist from menu panel:\t"
                        + title_playListLeftPanel + "\nValue match: " + compare + "\n");
            } else
                System.out.println("Playlists titles doesn't matched!\t" + title_playListCard + "\t" + title_playListLeftPanel);
        }
    }

    public int getAmountOfPlaylistsCards() {
        return waitForVisibility(playListsCards).size();
    }

}
