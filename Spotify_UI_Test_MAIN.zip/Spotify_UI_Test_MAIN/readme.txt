Spotify_UI_Test_MAIN tool was created for learning purposes only and is not a complete framework for automating testing or any works with websites.

This software solution is designed to automate the operation of a web browser and simulate some user actions on a website according to pre-planned scenarios.
Spotify_UI_Test_MAIN tool was developed and runs using the IntelliJ IDEA IDE. Performance in other development environments has not been tested.

Necessary preconditions for the work of software solution:
The launch and operation of the application requires a web driver (the latest versions of webdrivers for the most popular browsers can be found at 
https://www.selenium.dev/downloads/) and for the correct operation it is necessary to specify the location of the webdriver on the computer - for this in the 
src/main/java/utils/WebDriverSingleton.java class, the constants CHROME_DRIVER_PATH and FIREFOX_DRIVER_PATH should be assigned the values of the address 
where the webdriver is located. It is also necessary to specify the correct location of the test.ng file in the launch and debug settings.
Test scenarios of this project provide for work with the authorization of the user of the service, so you need to register a new account on the page https://www.spotify.com/signup.
Credentials of formed account put as keys of according values into src/test/java/resources/testData.properties file.